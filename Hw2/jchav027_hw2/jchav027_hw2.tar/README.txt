ASSUMPTIONS:

PARTS 1 AND 2:
* Assumed B0 is the START/STOP pin where START is 0 and STOP is 1. (In terms of the states, 
)
* Assumed B1 was the pin where the byte value is transferred through.

PART 3:
* Assumed B0 is SS
* Assumed B1 is where master sends bit
* Assumed B2 is where master receives bit
